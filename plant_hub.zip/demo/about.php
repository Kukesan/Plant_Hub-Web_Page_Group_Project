<!DOCTYPE html>
<html>
<head>
	<title>feedback</title>
</head>
<body>
	<?php
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

	$connection = mysqli_connect("localhost","root","") or die("Couldn't connect with server".mysqli_error($connection));
    
    $db = mysqli_select_db($connection,"planthub") or die("Database connection fails");

    $query="select * from message where name ='$name'";

    if($result=mysqli_query($connection,$query))
    {
            $query = "insert into message(name,email,subject,message)values('$name','$email','$subject','$message')";

            include 'about.html';

            if($result=mysqli_query($connection,$query))
            {
    		    echo mysqli_error($connection);
            }
            else
            {
                echo mysqli_error($connection);
            }
    }
    else
    {
        echo mysqli_error($connection);
    }

    mysqli_close($connection);
    
	?>

</body>
</html>