<!DOCTYPE html>
<html>
<head>
	<title>Sign Up</title>
</head>
<body>
	<?php
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $dob = $_POST['dob'];
    $uname = $_POST['uname'];
    $email = $_POST['email'];
    $pword = $_POST['pword'];
    $no = $_POST['no'];
    $town = $_POST['town'];
    $pcode = $_POST['pcode'];
    $country = $_POST['country'];

	$connection = mysqli_connect("localhost","root","") or die("Couldn't connect with server".mysqli_error($connection));
    
    $db = mysqli_select_db($connection,"planthub") or die("Database connection fails");

    $query="select * from user where uname ='$uname'";

    if($result=mysqli_query($connection,$query))
    {
    	if($row=mysqli_fetch_array($result))
    	{
    		echo "<h1>User name is already exits</h1><h2><a href = 'Signup.html'>Click Here</a></h2>";
    	}
    	else
    	{
            $query = "insert into user(fname, lname, dob, uname, email, pword, no, town, pcode, country)values('$fname', '$lname', '$dob', '$uname', '$email', '$pword', '$no','$town', '$pcode', '$country')";

            include('home.html');

            if($result=mysqli_query($connection,$query))
            {
    		echo mysqli_error($connection);
            }
            else
            {
                echo mysqli_error($connection);
            }
    	}
    }
    else
    {
        echo mysqli_error($connection);
    }

    mysqli_close($connection);
    
	?>

</body>
</html>