<!DOCTYPE html>
<html>
<title>Home page</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma">
<link rel='stylesheet' href='css/style1.css' type='text/css' media='all' />
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="sidebar-09/css/style.css">
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Karma", sans-serif}
.w3-bar-block .w3-bar-item {padding:20px}
</style>
<body>

<!-- Sidebar (hidden by default) -->
<div class="wrapper d-flex align-items-stretch">
			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	        </button>
        </div>
	  		<div class="img bg-wrap text-center py-4" style="background-image: url(images/bg_1.jpg);">
	  			<div class="user-logo">
	  				<div class="img" style="background-image: url(images/logo.jpg);"></div>
	  				<h3>Catriona Henderson</h3>
	  			</div>
	  		</div>
        <ul class="list-unstyled components mb-5">
          <li class="active">
            <a href="#"><span class="fa fa-home mr-3"></span> Home</a>
          </li>
          <li>
              <a href="#Plants"><span class="fa fa-download mr-3 notif"><small class="d-flex align-items-center justify-content-center">5</small></span>Plants</a>
          </li>
          <li>
            <a href="#new.html"><span class="fa fa-gift mr-3"></span> About</a>
          </li>
          <li>
            <a href="#loginpage.html"><span class="fa fa-trophy mr-3"></span>Logout</a>
          </li>
        </ul>

    	</nav>
    <script src="sidebar-09/js/jquery.min.js"></script>
    <script src="sidebar-09/js/popper.js"></script>
    <script src="sidebar-09/js/bootstrap.min.js"></script>
    <script src="sidebar-09/js/main.js"></script>

<!-- Top menu -->

  
<!-- !PAGE CONTENT! -->
<div id="content" class="p-4 p-md-5 pt-5">
<div class="w3-main w3-content w3-padding" style="max-width:1200px;margin-top:10px">
<div class="w3-row-padding w3-padding-16 w3-center" style="max-width:1200px;margin-top:10px">
<?php
    session_start();
    include('db.php');
    $status="";
    if (isset($_POST['code']) && $_POST['code']!=""){
    $code = $_POST['code'];
    $result = mysqli_query($con,"SELECT * FROM `products` WHERE `code`='$code'");
    $row = mysqli_fetch_assoc($result);
    $name = $row['name'];
    $code = $row['code'];
    $price = $row['price'];
    $image = $row['image'];
    
    $cartArray = array(
        $code=>array(
        'name'=>$name,
        'code'=>$code,
        'price'=>$price,
        'quantity'=>1,
        'image'=>$image)
    );
    
    if(empty($_SESSION["shopping_cart"])) {
        $_SESSION["shopping_cart"] = $cartArray;
        $status = "<div class='box'>Product is added to your cart!</div>";
    }else{
        $array_keys = array_keys($_SESSION["shopping_cart"]);
        if(in_array($code,$array_keys)) {
            $status = "<div class='box' style='color:red;'>
            Product is already added to your cart!</div>";	
        } else {
        $_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$cartArray);
        $status = "<div class='box'>Product is added to your cart!</div>";
        }
    
        }
    }
    ?>

    <div style="width:1050px; margin-left:10px;">
    
    <h2>Plants</h2>   
    
    <?php
    if(!empty($_SESSION["shopping_cart"])) {
    $cart_count = count(array_keys($_SESSION["shopping_cart"]));
    ?>
    <div class="cart_div">
    <a href="cart.php"><img src="cart-icon.png" /> Cart<span><?php echo $cart_count; ?></span></a>
    </div>
    <div class="plant">
    <?php
    }
    $result = mysqli_query($con,"SELECT * FROM `products`");
    while($row = mysqli_fetch_assoc($result)){
            echo "<div class='product_wrapper'>
                  <form method='post' action=''>
                  <input type='hidden' name='code' value=".$row['code']." />
                  <div class='image'><img src='".$row['image']."' /></div>
                  <div class='name'>".$row['name']."</div>
                     <div class='price'>$".$row['price']."</div>
                  <button type='submit' class='buy'>Buy Now</button>
                  </form>
                     </div>";
            }
    mysqli_close($con);
    ?>
    </div>
    </div>
    <div style="clear:both;"></div>
    
    <div class="message_box" style="margin:10px 0px;">
    <?php echo $status; ?></div>
          </div>
          </div>
  <!-- Pagination -->
  
  
  <hr id="about">

  <!-- About Section -->
  <div class="w3-container w3-padding-32 w3-center">  
    <h3>About Us, The Plant sellers</h3><br>
    <img src="https://images.pexels.com/photos/6231817/pexels-photo-6231817.jpeg?auto=compress&cs=tinysrgb&dpr=3&h=750&w=1260" alt="Me" class="w3-image" style="display:block;margin:auto" width="400" height="400">
    <div class="w3-padding-32">
      <h4><b>Who We are!</b></h4>
      <h6><i>With Passion For Real, Good Plants</i></h6>
      <p>Just us, ourselves and us, exploring the universe of unknownment. We have a heart of love and an interest of gardening .So we have started our indoor planting and for our happiness . Later it has become as sellling and expanding our indoor plant to you too. </p>
    
  <hr>
          </div>
          </div>
</div>
<script>
// Script to open and close sidebar
function w3_open() {
  document.getElementById("mySidebar").style.display = "block";
}
 
function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>

</body>
</html>
