var firstname = "";
var lastname = "";
var dob = "";
var no = "";
var town = "";
var postalcode = "";
var country = "";

function formValidation(thisform)
{
    with(thisform)
    {
        if(firstnameValidation(fname) == false)
        {
            return false;
        }
        if(lastnameValidation(lname) == false)
        {
            return false;
        }
        if(dobValidation(dob) == false)
        {
            return false;
        }
        if(usernameValidation(uname) == false)
        {
            return false;
        }
        if(emailValidation(email) == false)
        {
            return false;
        }
        if(passwordValidation(pword) == false)
        {
            return false;
        }
        if(conpasswordValidation(conpword) == false)
        {
            return false;
        }
        if(noValidation(no) == false)
        {
            return false;
        }
        if(townValidation(town) == false)
        {
            return false;
        }
        if(postalcodeValidation(pcode) == false)
        {
            return false;
        }
        if(countryValidation(country) == false)
        {
            return false;
        }
    }
}
        
        function firstnameValidation(fnmae)
        {
            with(document.form1)
            {
                if(fname.value=="")
                {
                    alert("First Name is not entered");
                    fname.focus();
                    return false;
                }
                else
                    return true;
            }
        }

        function lastnameValidation(lnmae)
        {
            with(document.form1)
            {
                if(lname.value=="")
                {
                    alert("Last Name is not entered");
                    lname.focus();
                    return false;
                }
                else
                    return true;
            }
        }

        function dobValidation(dob)
        {
            with(document.form1)
            {
                if(dob.value=="")
                {
                    alert("Date of Birth is not entered");
                    dob.focus();
                    return false;
                }
                else
                    return true;
            }
        }

        function usernameValidation(unmae)
        {
            with(document.form1)
            {
                if(uname.value=="")
                {
                    alert("User Name is not entered");
                    uname.focus();
                    return false;
                }
                else
                    return true;
            }
        }

        function emailValidation(email)
        {
            with(document.form1)
            {
                if(email.value=="")
                {
                    alert("Email is not entered");
                    email.focus();
                    return false;
                }
                else
                    return true;
            }
        }

        function passwordValidation(pword)
        {
            with(document.form1)
            {
                if(pword.value=="")
                {
                    alert("Password is not entered");
                    pword.focus();
                    return false;
                }
                else
                {
                    password=(pword.value).length;
                    if(password < 8)
                    {
                        alert("Password should have atleast 8 characters");
                        pword.focus();
                        return false;
                    }
                    else
                        return true;
                }
            }
        }

        function conpasswordValidation(conpword)
        {
            with(document.form1)
            {
                if(conpword.value=="")
                {
                    alert("Please confirm the password");
                    conpword.focus();
                    return false;
                }
                else
                {
                    
                    if(conpword.value!=pword.value)
                    {
                        alert("Wrong confirm password");
                        conpword.value = "";
                        conpword.focus();
                        return false;
                    }
                    else
                        return true;
                }
            }
        }

        function noValidation(no)
        {
            with(document.form1)
            {
                if(no.value=="")
                {
                    alert("No is not entered");
                    no.focus();
                    return false;
                }
                else
                    return true;
            }
        }

        function townValidation(town)
        {
            with(document.form1)
            {
                if(town.value=="")
                {
                    alert("Town is not entered");
                    town.focus();
                    return false;
                }
                else
                    return true;
            }
        }

        function postalcodeValidation(pcode)
        {
            with(document.form1)
            {
                if(pcode.value=="")
                {
                    alert("Postal Code is not entered");
                    pcode.focus();
                    return false;
                }
                else
                    return true;
            }
        }
        
        function countryValidation(country)
        {
            with(document.form1)
            {
                if(country.value=="")
                {
                    alert("Country is not entered");
                    country.focus();
                    return false;
                }
                else
                	return true;
            }
        }