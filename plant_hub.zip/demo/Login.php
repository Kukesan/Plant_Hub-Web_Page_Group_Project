<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
</head>
<body>
	<?php
  
  $uname = $_POST['uname'];
	$pword = $_POST['pword'];

	$connection = mysqli_connect("localhost","root","") or die("Couldn't connect with server".mysqli_error($connection));
    
    $db = mysqli_select_db($connection,"planthub") or die("Database connection fails");

    $query = "select * from user where uname ='$uname'";

   	if($result = mysqli_query($connection,$query))
   	{
   		if(!($row = mysqli_fetch_array($result)))
   		{
   			echo "<h1>Invalid User Name</h1><h2><a href = 'Login.html'>Click Here</a></h2>";
   		}
   		else
   		{
	   		$password = $row[5];
	   		if($password == $pword)
	   		{
	   			include('home.html');
	   		}
	   		else
	   		{
	   			echo "<h1>Invalid Password</h1><h2><a href = 'Login.html'>Click Here</a></h2>";
	   		}
   		}
   	}
	else
   	{
   		echo mysqli_error($connection);
   	}
   		
   	mysqli_close($connection);
   	
	?>

</body>
</html>