-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2021 at 05:26 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `planthub`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `code` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `totalprice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`code`, `quantity`, `totalprice`) VALUES
(0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`name`, `email`, `subject`, `message`) VALUES
('0', 'kamal@gmail.com', 'test1', 'hello'),
('0', 'kamal@gmail.com', 'test1', 'hello'),
('0', 'kamal@gmail.com', 'test1', 'hello'),
('0', 'kamal@gmail.com', 'test1', 'hello'),
('0', 'kamal@gmail.com', 'test1', 'hello'),
('0', 'kamal@gmail.com', 'test2', 'kk'),
('kamal', 'kamal@gmail.com', 'test1', 'hello'),
('kathu', 'kathu@gmail.com', 'test3', 'hai'),
('Sobi', 'sobi@gmail.com', 'test6', 'dd'),
('Kamal', 'kamal@gmail.com', 'test1', 'hello');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `name` varchar(250) NOT NULL,
  `code` varchar(100) NOT NULL,
  `price` double(9,2) NOT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `code`, `price`, `image`) VALUES
(1, 'Mint', 'mint01', 10.00, 'plants/001a.jpg'),
(2, 'Sansevieria', 'Sansevieria2', 15.00, 'plants/002a.jpg'),
(3, 'Green succulent', 'Greensucculent1', 9.00, 'plants/003a.png'),
(4, 'Green cuctus', 'Greencuctus71', 12.00, 'plants/004a.png'),
(5, 'Snake plant', 'Snakeplant101', 20.00, 'plants/005a.png'),
(6, 'Potted cactus', 'Pottedcactus027', 9.00, 'plants/006a.png'),
(7, 'Oregano', 'Oregano03', 6.00, 'plants/007a.png'),
(8, 'Palm tree', 'Palmtree045', 12.50, 'plants/008a.png'),
(9, 'Triangularis', 'Triangularis99', 2.75, 'plants/009a.png'),
(10, 'Fiddle leaf fig', 'Fiddleleaffig527', 6.00, 'plants/010a.png'),
(11, 'Tree fern', 'Treefern567', 30.00, 'plants/011a.png'),
(12, 'Corn plant', 'Cornplant781', 10.00, 'plants/012a.png'),
(13, 'Butterfly plant', 'Butterflyplant484', 8.00, 'plants/013a.png'),
(14, 'Ficus petiolaris', 'Ficuspetiolaris586', 32.00, 'plants/014a.png'),
(15, 'Tropical ficus elastica', 'Tropicalficuselastica86', 5.00, 'plants/015a.png'),
(16, 'Tulip plant', 'Tulipplant694', 42.00, 'plants/016a.png'),
(17, 'Orchid', 'Orchid33', 32.00, 'plants/017a.png'),
(18, 'Monstera', 'Monstera77', 28.00, 'plants/018a.png');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `dob` varchar(12) NOT NULL,
  `uname` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pword` varchar(25) NOT NULL,
  `no` varchar(15) NOT NULL,
  `town` varchar(15) NOT NULL,
  `pcode` varchar(15) NOT NULL,
  `country` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`fname`, `lname`, `dob`, `uname`, `email`, `pword`, `no`, `town`, `pcode`, `country`) VALUES
('Kumar', 'Kapi', '2021-07-21', 'Kapi', 'kapi@gmail.com', 'Kapi1234', '3', 'jaffna', '1200', 'Sri Lanka'),
('Ketheeswaran', 'Kukesan', '2021-07-28', 'Kukesan', 'kuke@gamil.com', 'kuke1234', '1', 'Jaffna', '123', 'Srilanka'),
('Kumar', 'Kamal', '2021-07-29', 'Kumar', 'kamal@gmail.com', 'Kamal1234', '03', 'jaffna', '1200', 'Sri Lanka');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`code`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
