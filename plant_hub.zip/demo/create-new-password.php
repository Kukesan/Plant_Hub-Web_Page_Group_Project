  <?php
session_start();
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
    <meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="css/style.css?v=35678676799">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <body>
   
    </div>
   <div class="container2">
   <img src="img/icon2.png">
    <div class="heading"><p>Create New Password</p></div>
    <div class="conta">
 
    <?php
         $selector = $_GET["selector"];
         $validator = $_GET["validator"];

       
             if(ctype_xdigit($selector)!==false && ctype_xdigit($validator)!==false) {
                 ?>
           <form action= "include/reset-password.inc.php" method = "post">
           <input type="hidden" name="selector" value = "<?php echo $selector?>" >
           <input type="hidden" name="validator" value = "<?php echo $validator?>">
           <input type="password" placeholder="Enter your new password" name="password" required>
           <input type="password" placeholder="Confirm password" name="confirm_password" required>
           <div class="reset">
           <button type="submit" name="reset-password-submit">Reset </button>
           </div>
           <?php
             }
        // }


        ?>
            
         </div>
         
        </form>
        </div>
    </div>
    <button class='button1'>
          <a href="">HOME >>></a>
         </button>
       

    </body>
        
</html>  